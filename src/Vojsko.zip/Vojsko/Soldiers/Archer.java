package Vojsko.Soldiers;

public class Archer extends Soldier {

    public final String type = "DEFENSIVE";
    public String protect;

    public Archer(String name, String protect) {
        super(name);
        this.protect = protect;
    }

    public void addArcher(Archer archer) {
        archers.add(archer);
    }

    public String getProtect() {
        return protect;
    }

    public String getType() {
        return type;

    }
}
