package Vojsko;

import Vojsko.Soldiers.Soldier;

import java.util.ArrayList;

public class Army implements Commands {
    private ArrayList<Soldier> soldiers;


    public void getInstructions(){
        System.out.println("Select '1' for Report");
        System.out.println("Select '2' for Attack");
        System.out.println("Select '3' for Defend");
    }

    @Override
    public void command(int x) {
        if (x == 1){

        } else if (x == 2){

        } else if (x == 3) {
            System.out.println("3");
        } else {
            System.out.println("Command is unknown");
        }
    }

    public void report(){

    }
}
