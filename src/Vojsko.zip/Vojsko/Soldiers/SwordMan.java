package Vojsko.Soldiers;

public class SwordMan extends Soldier {

    public final String type = "OFFENSIVE";
    public String damage;

    public SwordMan(String name, String damage) {
        super(name);
        this.damage = damage;
    }

    public void addSwordMan(SwordMan swordMan){
        swordMens.add(swordMan);
    }

    public String getDamage() {
        return damage;
    }

    public String getType() {
        return type;
    }



}
