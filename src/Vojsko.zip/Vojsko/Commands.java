package Vojsko;

public interface Commands {

    default void command(int x){

    }

}
