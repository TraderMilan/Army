package Vojsko.Soldiers;

import Vojsko.Army;

import java.util.ArrayList;

public class Soldier extends Army {
    private final String title = "Soldier";
    private final String status = "here";
    protected ArrayList<SwordMan> swordMens;
    protected ArrayList<Archer> archers;

    protected String name;

    public Soldier(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
    public String getStatus() {
        return status;
    }
    public ArrayList<SwordMan> getSwordMens() {
        return swordMens;
    }
    public String getTitle() {
        return title;
    }


    public void Attack(){
        for (SwordMan swordMan: swordMens){
            System.out.println(getName() + swordMan.getDamage());
        }
    }

    public void Defend(){
        for (Archer archer: archers){
            System.out.println(getName() + archer.getProtect());
        }
    }

}


